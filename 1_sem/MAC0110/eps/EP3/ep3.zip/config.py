R = float(input('Entre com R: '))
n = int(input('Entre com n: '))