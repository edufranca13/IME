int binarysearchfo(tuple v[], int inicio, int fim, int x);

int binarysearchfoi(int v[], int inicio, int fim, int x);