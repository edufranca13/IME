void merge(int *v, int inicio, int meio, int fim);

void mergesort(int *v, int inicio, int fim);
